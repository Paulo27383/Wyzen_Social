# WYZEN SOCIAL
Base de desenvolvimento Android com Expo, React Native, TypeScript e Supabase.

## Incluído
- Registo/login por email e sessão persistente.
- Feed e publicação de texto.
- Upload inicial de imagem/vídeo para Supabase Storage.
- Gostos e comentários (operações base).
- Esquema de perfis, follows, reposts, conversas, mensagens, notificações, bloqueios e denúncias.
- Migração SQL inicial, RLS, workflows GitHub e configuração EAS para APK.

## Limitações honestas
Este pacote NÃO é uma rede social completa pronta para produção. A interface implementa autenticação, feed, publicação e upload básico; pesquisa, chat em tempo real, stories, notificações push, painel de administração, moderação operacional e edição completa de perfil ainda exigem implementação. O SQL é uma base inicial e deve ser revisto/testado antes de abrir a plataforma ao público. Não contém APK.

## Configuração
1. Crie/abra o projecto Supabase.
2. Execute `supabase/migrations/0001_wyzen_social.sql` no SQL Editor.
3. Copie Project URL e a chave pública publishable/anon.
4. Defina `EXPO_PUBLIC_SUPABASE_URL` e `EXPO_PUBLIC_SUPABASE_ANON_KEY` no ambiente de build.
5. Nunca coloque `service_role` ou secret key na app nem no GitHub.

## Executar
`npm install`, criar `.env` a partir de `.env.example`, depois `npx expo start`.

## APK
Com EAS configurado: `npm install -g eas-cli`, `eas login`, `eas build:configure`, `eas build --platform android --profile preview`.

O workflow de descompactação é manual: o GitHub não extrai automaticamente um ZIP apenas por o receber. Consulte `docs/SETUP_GITHUB_MOBILE.md`.
