# Roadmap
## Base incluída
Auth, sessão persistente, feed inicial, criação de posts, upload básico de mídia, likes/comentários simples e schema para follows, reposts, mensagens, notificações, blocks e reports.

## Ainda a implementar/testar
- Pesquisa de utilizadores e hashtags.
- Perfil editável, avatar, seguidores/seguidos.
- Feed personalizado e paginação.
- Chat completo em tempo real e anexos.
- Stories e leitor de vídeo.
- Notificações in-app e push.
- Ferramentas administrativas e fila de denúncias.
- Moderação, anti-spam, rate limits e validação server-side.
- Testes automatizados, acessibilidade, backups e auditoria de segurança.
