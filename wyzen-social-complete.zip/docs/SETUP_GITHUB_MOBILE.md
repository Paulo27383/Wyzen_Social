# Instalação pelo Android
1. Carregue `wyzen-social-complete.zip` para a raiz do repositório.
2. O workflow `unpack-wyzen.yml` tem de estar primeiro dentro de `.github/workflows/` no repositório para poder ser executado. Como o workflow está dentro do ZIP, a primeira extracção tem de ser feita pelo gestor de ficheiros do Android ou por Codespaces.
3. Depois de o workflow estar instalado, abra GitHub → Actions → Unpack WYZEN ZIP → Run workflow.
4. Se falhar, confirme Settings → Actions → General → Workflow permissions: Read and write permissions.
